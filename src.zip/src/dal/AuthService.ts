import { eq } from "drizzle-orm";
import type { DbClient } from "./db/client";
import { usersTable } from "./db/schema";
import bcrypt from "bcrypt";

export class AuthService {
  constructor(private readonly db: DbClient) {}

  async register(email: string, password: string) {
    const hashed = await bcrypt.hash(password, 10);

    const [user] = await this.db
      .insert(usersTable)
      .values({
        email,
        password: hashed,
      })
      .returning();

    if (!user) throw new Error("Failed to create user");

    return user;
  }

  async login(email: string, password: string) {
    const user = await this.db.query.usersTable.findFirst({
      where: eq(usersTable.email, email),
    });

    if (!user) throw new Error("User not found");

    const valid = await bcrypt.compare(password, user.password);

    if (!valid) throw new Error("Invalid password");

    return user;
  }
}